const express = require('express');
const router = express.Router();
const db = require('../db');
const authMiddleware = require('./authMiddleware');

// 获取所有站点设置
router.get('/', (req, res) => {
    db.all('SELECT * FROM settings', [], (err, rows) => {
        if (err) {
            return res.status(500).json({ error: err.message });
        }
        const settings = {};
        rows.forEach(row => {
            settings[row.key] = row.value;
        });
        res.json(settings);
    });
});

// 更新站点设置（需要认证）
router.put('/', authMiddleware, (req, res) => {
    const settings = req.body;
    if (!settings || typeof settings !== 'object') {
        return res.status(400).json({ error: '无效的设置数据' });
    }

    const stmt = db.prepare('INSERT OR REPLACE INTO settings (key, value) VALUES (?, ?)');
    let completed = 0;
    const keys = Object.keys(settings);

    if (keys.length === 0) {
        return res.json({ message: '设置已更新' });
    }

    keys.forEach(key => {
        stmt.run(key, settings[key], function (err) {
            if (err) {
                console.error(`保存设置 ${key} 失败:`, err);
            }
            completed++;
            if (completed === keys.length) {
                stmt.finalize();
                res.json({ message: '设置已更新' });
            }
        });
    });
});

module.exports = router;